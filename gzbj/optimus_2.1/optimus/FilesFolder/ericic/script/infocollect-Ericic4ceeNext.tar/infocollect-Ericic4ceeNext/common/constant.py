#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Author: fan.a.wang@ericsson.com

####################################################
# Modify to adapt to the ceeNext network environment
# host info
try:
    from common.node_list import CICS as _CICS
    from common.node_list import COMPUTES as _COMPUTES
    from common.node_list import ALL_NODES as _ALL_NODES
    from common.node_list import OPENSTACK_RC_FILE

    CIC1 = _CICS[0]
    CICS = _CICS
    COMPUTES = _COMPUTES
    ALL_NODES = _ALL_NODES
    _OPENRC_FILE = OPENSTACK_RC_FILE
except:
    CIC1 = 'cic-1'
    CIC2 = 'cic-2'
    CIC3 = 'cic-3'
    COMPUTE1 = "compute1"

    CICS = [CIC1, CIC2, CIC3]
    COMPUTES = [COMPUTE1]
    # COMPUTES = [COMPUTE1, COMPUTE2, COMPUTE3, COMPUTE4]
    ALL_NODES = CICS + COMPUTES
    _OPENRC_FILE = "/var/lib/cee/system/DL33/system/openstack/admin-openrc.sh"


# if want to run some of the case ,just modify RUN_TEST_CASE
# for example: RUN_TEST_CASE = ["test_1_1"]
# RUN_TEST_CASE = ["test_optimue_001"]
RUN_TEST_CASE = []


###################################
# test cases
TEST_MOUDLE = {
    "vm_usage": [
        "test_optimue_001"
    ]
}

#################################
# output excel file Resource_Management_Statistics.xlsx, and sheet info
OUTPUT_USAGE = "Resource_Management_Statistics.xlsx"
OUTPUT_USAGE_SHEETS = []
#################################

OUTPUT_INFOS = {
    OUTPUT_USAGE: OUTPUT_USAGE_SHEETS
}

# command part
OPENRC_FILE = ". " + _OPENRC_FILE
TOKEN = "openstack token issue -f json"
ENDPOINT_INFOS = "openstack endpoint list --long  -c 'Service Name' -c 'PublicURL' -f json"
FLAVOR = "openstack flavor list -f json"
DETAILS = "nova list --all-tenant --fields id,name,status," \
          "OS-EXT-STS:power_state,flavor,created," \
          "OS-EXT-SRV-ATTR:host,OS-EXT-AZ:availability_zone,instance_name,tenant_id,networks |" \
          " grep -vw 'OS-EXT-AZ: Availability Zone' |" \
          " grep -vw 'Tenant ID' | grep -v '+'"
AGGREGATE_LIST = "openstack aggregate list -c Name -f json"
AGGREGATE_SHOW = "openstack aggregate show %s  -c availability_zone -c hosts -c name -f json"
HYPERVISOR = "openstack hypervisor list --long -f json"
HYPERVISOR_DISK = "openstack hypervisor show %s | " \
                  "egrep 'local_gb|local_gb_used'"
VOLUME = "openstack volume list  --long -f json"
PROJECT = "openstack project list -f json"
HYPERVISOR_STAT = "openstack hypervisor stats show  -f json"
QUOTA_COMPUTE = "openstack quota list --compute -f json"
QUOTA_VOLUME = "openstack quota list --volume -f json"
PROJECT_QUOTA_COMPUTE_USAGE = "openstack quota list --project %s --compute --detail  -f json"
VOLUME_QUOTA_COMPUTE_USAGE = "cinder quota-usage %s | grep -w gigabytes"
