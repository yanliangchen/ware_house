#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import re
import sys
import json
import uuid
import argparse
import warnings
warnings.filterwarnings("ignore")
sys.path.append(".")
sys.path.append("..")
from common.common import call_subprocess, \
    get_vim_init_data, write2logfile
from common.constant import *
from common.common import BaseWrokbook, InitWorkbook
base_path = os.path.split(os.path.realpath(__file__))[0]
case_name = os.path.basename(__file__).split('.py')[0]

# nodes = COMPUTES
# excel_file = OUTPUT_USAGE


def prepare():
    OUTPUT_INFOS[excel_file] = []
    sheet_info = {
        "DC_Static":
            {
                "header":
                    [
                        "Total CPU", "Total Mem (GB)", "Total Local Disk（GB)",
                        "Total Volume (GB)", "CPU Usage Rate", "Mem Usage Rate",
                        "Local Disk Usage Rate", "Volume Usage Rate"
                    ],
                "format_info": [
                    {
                        "position": ["A1", "D1"],
                        "information": "Total Hypervisor Resource of Current Datacenter",
                        "data_location": [1, 1]
                    },
                    {
                        "position": ["E1", "H1"],
                        "information": "Utilization Rate of Hypervisor Resource",
                        "data_location": [1, 5]
                    }]
            },
        "Tenant_Static":
            {
                "header":
                    [
                        "Tenant Name", "CPU Quota", "Mem Quota", "Volume Quota",
                        "CPU Usage Rate", "Mem Usage Rate", "Volume Usage Rate"
                    ],
                "format_info": [
                    {
                        "position": ["A1", "D1"],
                        "information": "Tenant Quotas",
                        "data_location": [1, 1]
                    },
                    {
                        "position": ["E1", "G1"],
                        "information": "Utilization Rate of Tenant Quotas",
                        "data_location": [1, 5]
                    }]
            },
        "VM_Static":
            {
                "header":
                    [
                        "Tenant Name", "UUID", "Name", "Status", "Power State",
                        "Created Time", "Networks", "Host", "Host Aggregate",
                        "Availability Zone", "Compute State", "infra CPU",
                        "infra Mem", "infra Disk", "NUMA Layout", "cpu",
                        "mem", "disk", "volume name", "volume state",
                        "volume size", "volume type", "bootable"
                    ],
                "format_info": [
                    {
                        "position": ["B1", "G1"],
                        "information": "VM Fields",
                        "data_location": [1, 2]
                    },
                    {
                        "position": ["H1", "O1"],
                        "information": "Host Fields",
                        "data_location": [1, 8]
                    },
                    {
                        "position": ["P1", "W1"],
                        "information": "Flavor & Resources",
                        "data_location": [1, 16]
                    }]
            }
    }

    for sheet_name in sheet_info.keys():
        OUTPUT_INFOS[excel_file].append(
            {
                'sheet': sheet_name,
                'data': []
            }
        )
    return sheet_info


def get_flavors():
    result, _ = call_subprocess(
        FLAVOR, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def get_vm_details():
    ret = []
    keys = [
        'id', 'name', 'status', 'power_state', 'flavor',
        'created', 'host', 'az', 'instance_name',
        'tenant_id', 'networks'
    ]
    result, _ = call_subprocess(
        DETAILS, openrc=True
    )
    # print(result)
    if result and (not _):
        return []

    if (not result) or (not result.strip()):
        return []

    if isinstance(result, bytes):
        result = result.decode()

    infos = result.replace('|', '').strip().split('\n')

    for info in infos:
        tmp = {}
        _ = info.strip().split()
        # print(_)
        # print('\n')
        if len(_) < len(keys):
            _num = len(keys) - len(_)
            _.extend(['' for x in range(_num)])
        for i in range(len(keys)):
            tmp[keys[i]] = _[i]
            if i == len(keys) - 1:
                tmp[keys[i]] = ''.join(_[i:])
        ret.append(tmp)
    return ret


def get_aggregate():
    ret = []
    result, _ = call_subprocess(
        AGGREGATE_LIST, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    aggs = json.loads(result)
    for agg in aggs:
        tmp, _ = call_subprocess(
            AGGREGATE_SHOW % agg.get('Name'), openrc=True
        )
        ret.append(json.loads(tmp))

    return ret


def get_hypervisor():
    result, _ = call_subprocess(
        HYPERVISOR, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        _data = json.loads(result)
        for _d in _data:
            # ret, _ = call_subprocess(
            #     HYPERVISOR_DISK % _d.get("ID"), openrc=True
            # )
            # if isinstance(ret, bytes):
            #     ret = ret.decode()
            # # print(ret)
            # local_gb = local_gb_used = 0
            # for r in ret.strip().split('\n'):
            #     if re.search('local_gb_used', r):
            #         local_gb_used = int(r.split('|')[-2].strip())
            #     elif re.search('local_gb', r):
            #         local_gb = int(r.split('|')[-2].strip())
            # # print(local_gb, local_gb_used)
            # _d['Free Disk'] = local_gb - local_gb_used
            # _d['Total Disk'] = local_gb

            _d['vCPUs Used'] = 0
            _d['vCPUs'] = 0
            _d['Memory MB Used'] = 0
            _d['Memory MB'] = 0
            _d['Free Disk'] = 0
            _d['Total Disk'] = 0
        # print(_data)
        return _data


def get_project():
    result, _ = call_subprocess(
        PROJECT, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def get_volume():
    result, _ = call_subprocess(
        VOLUME, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def get_dc_stat():
    result, _ = call_subprocess(
        HYPERVISOR_STAT, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def quota_compute():
    result, _ = call_subprocess(
        QUOTA_COMPUTE, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def quota_volume():
    result, _ = call_subprocess(
        QUOTA_VOLUME, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def project_quote_compute_usage(tenants):
    ret = []
    for tenant in tenants:
        temp = {}
        result, _ = call_subprocess(
            PROJECT_QUOTA_COMPUTE_USAGE % tenant.get("ID"), openrc=True
        )
        for r in json.loads(result):
            temp["ID"] = tenant.get("ID")
            if r.get("Resource") == "ram":
                temp["Ram In_use"] = r.get("In Use")
                temp["Ram Limit"] = r.get("Limit")
            elif r.get("Resource") == "cores":
                temp["Core In_use"] = r.get("In Use")
                temp["Core Limit"] = r.get("Limit")

        ret.append(temp)
    return ret


def project_quote_volume_usage(tenants):
    ret = []
    for tenant in tenants:
        temp = {}
        temp["ID"] = tenant.get("ID")
        result, _ = call_subprocess(
            VOLUME_QUOTA_COMPUTE_USAGE % tenant.get("ID"), openrc=True
        )
        if isinstance(result, bytes):
            result = result.decode()
        temp["Gigabytes In_use"] = int(result.strip().split('|')[2])
        temp["Gigabytes Limit"] = int(result.strip().split('|')[4])
        ret.append(temp)
    return ret


def get_data():
    flavors = get_flavors()
    vms = get_vm_details()
    ha = get_aggregate()
    computes = get_hypervisor()
    tenants = get_project()
    volume = get_volume()
    dc_infos = get_dc_stat()
    compute_quota = quota_compute()
    volume_quota = quota_volume()

    usage_compute_quata = usage_volume_quata = []
    if tenants:
        usage_compute_quata = project_quote_compute_usage(tenants)
        usage_volume_quata = project_quote_volume_usage(tenants)
    return {
        "flavor": flavors,
        "vm_info": vms,
        "aggregate": ha,
        "compute_info": computes,
        "tenants": tenants,
        "volume": volume,
        "dc_info": dc_infos,
        "compute_quota": compute_quota,
        "volume_quota": volume_quota,
        "usage_compute_quata": usage_compute_quata,
        "usage_volume_quata": usage_volume_quata
    }


def gen_all_data(sheet_info=None):
    if dc_status == "online":
        data_infos = get_data()

        # local test code
        # with open("..//bj_lab.json") as f:
        #     data_infos = f.read()
        # data_infos = json.loads(data_infos)

        filename = base_path + os.sep + '..' + os.sep + \
                   "output" + os.sep + output_json_file
        if os.path.exists(filename):
            os.remove(filename)
        write2logfile(json.dumps(data_infos), filename)
    elif dc_status == "offline":
        with open(input_json_file) as f:
            data_infos = f.read()
        try:
            data_infos = json.loads(data_infos)
        except Exception as e:
            print("FORMAT ERROR: Input file format must be json")
            print(e)
            sys.exit(2)

    try:
        flavors = data_infos.get('flavor')
        vms = data_infos.get('vm_info')
        ha = data_infos.get('aggregate')
        computes = data_infos.get('compute_info')
        volumes = data_infos.get('volume')
        tenants = data_infos.get('tenants')
        dc_info = data_infos.get('dc_info')
        compute_quota = data_infos.get('compute_quota')
        volume_quota = data_infos.get('volume_quota')
        usage_compute_quata = data_infos.get('usage_compute_quata')
        usage_volume_quata = data_infos.get('usage_volume_quata')
    except:
        if dc_status == "offline":
            print("ERROR: invalid input DC json file!")
        else:
            print("ERROR: something wrong,when get VIM information")
        sys.exit(3)

    def call_dc_handel(dc_info):
        tmp = []
        vcpus = dc_info.get("vcpus")
        memory_gb = int(int(dc_info.get("memory_mb"))/1024)
        local_gb = dc_info.get("local_gb")
        volume_gb = None
        memory_used = dc_info.get("memory_mb_used")
        vcpu_usage = int(dc_info.get("vcpus_used"))/int(vcpus) * 100
        mem_usage = int(memory_used)/int(dc_info.get("memory_mb")) * 100
        local_usage = int(dc_info.get("local_gb_used"))/int(local_gb) * 100
        volume_usage = None

        tmp.append(
            [
                vcpus, memory_gb, local_gb, volume_gb,
                '{:.2f}'.format(vcpu_usage)+"%",
                '{:.2f}'.format(mem_usage)+"%",
                '{:.2f}'.format(local_usage)+"%", volume_usage
            ]
        )
        return tmp

    def call_tenant_handel(tenants, compute_quota, volume_quota_datas,
                usage_compute_quata, usage_volume_quata):
        tmp = []
        for tenant in tenants:
            tenant_id = tenant.get("ID")
            tenant_name = tenant.get("Name")

            cpu_quota = mem_quota = None
            if compute_quota:
                for _compute_quota in compute_quota:
                    if _compute_quota.get("Project ID") == tenant_id:
                        cpu_quota = _compute_quota.get("Cores")
                        mem_quota = _compute_quota.get("Ram")
                        break

            volume_quota = None
            if volume_quota_datas:
                for volume_quota_data in volume_quota_datas:
                    if volume_quota_data.get("Project ID") == tenant_id:
                        volume_quota = volume_quota_data.get("Gigabytes")
                        break

            cpu_usage_rate = mem_usage_rate = None
            if usage_compute_quata:
                for _usage_compute_quata in usage_compute_quata:
                    if _usage_compute_quata.get("ID") == tenant_id:
                        Cpu_In_use = _usage_compute_quata.get("Core In_use")
                        Cpu_Limit = _usage_compute_quata.get("Core Limit")
                        Mem_In_use = _usage_compute_quata.get("Ram In_use")
                        Mem_Limit = _usage_compute_quata.get("Ram Limit")
                        if Cpu_Limit != -1:
                            cpu_usage_rate = int(Cpu_In_use)/int(Cpu_Limit)*100
                        else:
                            cpu_usage_rate = -1
                        if Mem_Limit != -1:
                            mem_usage_rate = int(Mem_In_use)/int(Mem_Limit)*100
                        else:
                            mem_usage_rate = -1
                        break

            volume_usage_rate = None
            if usage_volume_quata:
                for _usage_volume_quata in usage_volume_quata:
                    if _usage_compute_quata.get("ID") == tenant_id:
                        Volume_In_use = _usage_volume_quata.get("Gigabytes In_use")
                        Volume_Limit = _usage_volume_quata.get("Gigabytes Limit")
                        volume_usage_rate = int(Volume_In_use)/int(Volume_Limit)*100
                        break
            tmp.append(
                [
                    tenant_name, cpu_quota, mem_quota, volume_quota,
                    '{:.2f}'.format(cpu_usage_rate)+"%",
                    '{:.2f}'.format(mem_usage_rate)+"%",
                    '{:.2f}'.format(volume_usage_rate)+"%"
                ]
            )
        return tmp

    def call_vm_handel(tenants, vms, computes, ha, flavors, volumes):
        tmp = []
        if not computes:
            tmp.append(
                [None for i in range(len(sheet_info.get("VM_Static").get("header")))]
            )
            return tmp
        else:
            for compute in computes:
                compute_status = compute.get('State', None)
                host = compute.get('Hypervisor Hostname', None)
                compute_cpu = compute.get('vCPUs', None)
                compute_mem_mb = compute.get('Memory MB', None)
                compute_disk = compute.get('Total Disk', None)
                compute_numa = None

                HA = None
                AZ = 'nova'
                if ha:
                    for agg in ha:
                        if host in agg.get('hosts'):
                            HA = agg.get('name')
                            AZ = agg.get('availability_zone')
                            break

                none_vms_and_compute = [
                    None, None, None, None, None, None, None,
                    host, HA, AZ, compute_status, compute_cpu,
                    compute_mem_mb, compute_disk, compute_numa,
                    None, None, None, None, None, None, None,
                    None
                ]
                if not vms:
                    if none_vms_and_compute not in tmp:
                        tmp.append(
                            none_vms_and_compute
                        )
                else:
                    for vm in vms:
                        # get tenant_name
                        tenant_id = vm.get('tenant_id')
                        tenant_name = None
                        for _tenant in tenants:
                            if _tenant.get("ID") == tenant_id:
                                tenant_name = _tenant.get("Name")
                                break

                        if not re.search(vm.get('host'), host):
                            if none_vms_and_compute not in tmp:
                                tmp.append(
                                    none_vms_and_compute
                                )
                        else:
                            if none_vms_and_compute in tmp:
                                tmp.remove(none_vms_and_compute)
                            vm_id = vm.get('id')
                            vm_name = vm.get('name')
                            vm_status = vm.get('status')
                            create = vm.get('created')
                            network = vm.get('networks')

                            if int(vm.get('power_state')) == 1:
                                vm_power_state = 'Running'
                            elif int(vm.get('power_state')) == 0:
                                vm_power_state = 'NOSTATE'
                            elif int(vm.get('power_state')) == 4:
                                vm_power_state = 'Shutdown'

                            cpu = ram = disk = None
                            for flavor in flavors:
                                if vm.get('flavor') == flavor.get('ID'):
                                    cpu = flavor.get('VCPUs')
                                    ram = flavor.get('RAM')
                                    disk = flavor.get('Disk')

                            volume_name = volume_state = volume_size\
                                = volume_type = volume_bootable = None
                            if volumes:
                                for volume in volumes:
                                    attachs = volume.get("Attached to", None)
                                    if attachs:
                                        for attach in attachs:
                                            attach_id = attach.get("server_id", None)
                                            if attach_id == "vm_id":
                                                volume_name = volume.get("Name")
                                                volume_state = volume.get("Status")
                                                volume_size = volume.get("Size")
                                                volume_type = volume.get("Type")
                                                volume_bootable = volume.get("Bootable")
                                                break
                            tmp.append(
                                [
                                    tenant_name, vm_id, vm_name, vm_status,
                                    vm_power_state, create, network, host,
                                    HA, AZ, compute_status, compute_cpu,
                                    compute_mem_mb, compute_disk, compute_numa,
                                    cpu, ram, disk, volume_name, volume_state,
                                    volume_size, volume_type, volume_bootable
                                ]
                            )

                temp = []
                for d in tmp:
                    temp.append(d[7])
                if temp.count(host) >= 2:
                    if none_vms_and_compute in tmp:
                        tmp.remove(none_vms_and_compute)
        return tmp

    for k, v in sheet_info.items():
        data = get_vim_init_data(
            OUTPUT_INFOS, excel_file,
            k,
            v.get("header")
        )
        if k == "DC_Static":
            if dc_info:
                _data = call_dc_handel(dc_info)
                data.extend(_data)
        elif k == "Tenant_Static":
            _data = call_tenant_handel(
                tenants, compute_quota, volume_quota,
                usage_compute_quata, usage_volume_quata
            )
            data.extend(_data)
        elif k == "VM_Static":
            _data = call_vm_handel(
                tenants, vms, computes, ha, flavors, volumes
            )
            data.extend(_data)


def write2excel(sheet_info):
    for file, sheet_infos in OUTPUT_INFOS.items():
        output_path = base_path + os.sep + '..' + \
                      os.sep + "output"
        file = output_path + os.sep + file
        if os.path.exists(file):
            os.remove(file)
        workbook = InitWorkbook(file).wb
        wb = BaseWrokbook(file, workbook)
        _sheet_infos = []
        for s in sheet_infos:
            if s not in _sheet_infos:
                _sheet_infos.append(s)
        for _sheet_info in _sheet_infos:
            _sheet = _sheet_info.get('sheet', None)
            data = _sheet_info.get('data', None)
            if _sheet and len(_sheet) >= 31:
                sheet = _sheet[-30:]
            else:
                sheet = _sheet
            if sheet:
                wb.init_sheet(titles=[sheet])
            if data and sheet:
                for k, v in sheet_info.items():
                    if k == sheet:
                        format_infos = v.get("format_info")
                wb.write(
                    input=data, sheet=sheet, step=1,
                    format_infos=format_infos
                )


def main():
    sheet_info = prepare()
    gen_all_data(sheet_info)
    write2excel(sheet_info)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=(
        'Using VIM infomation to generate excel file!'))
    parser.add_argument('-s', '--status', required=False,
                        default='online', choices=['offline', 'online'],
                        help='status of DC, must in <offline/online>')
    parser.add_argument('-i', '--job_id', required=False,
                        default=''.join(str(uuid.uuid4()).split('-')),
                        help='output json file name.'
                        )
    parser.add_argument('-f', '--json_file',
                        required=False, default=None,
                        help='if DC status is offline, '
                             'must input DC offline json file!'
                        )
    parser.add_argument('-n', '--dc_id',
                        required=False, default="dc",
                        help='the id of DC'
                        )
    args = parser.parse_args()
    dc_status = args.status
    output_json_file = args.job_id + '.json'
    input_json_file = args.json_file
    if dc_status == "offline" and (not input_json_file):
        print("if DC status is offline, you must input DC json file"
              " to genarate finnal excel file. Usage --json_file/-f"
              )
        sys.exit(1)
    excel_file = "%s_%s.xlsx" % (args.dc_id, args.job_id)
    main()

