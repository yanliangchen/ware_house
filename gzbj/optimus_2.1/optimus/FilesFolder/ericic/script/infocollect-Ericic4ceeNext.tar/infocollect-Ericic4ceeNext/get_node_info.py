#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Author: fan.a.wang@ericsson.com
# execute node: lcm

import os
import re
import sys
import argparse
from subprocess import check_output, CalledProcessError

base_path = os.path.split(
    os.path.realpath(__file__))[0]
node_info = base_path + os.sep + 'common' + os.sep + 'node_list.py'


def call_subprocess(cmd, host=False):
    flag = True
    try:
        if host:
            cmd = 'ssh %s "%s"' % (host, cmd)
        print("run command :%s" % cmd)
        print('\n')
        result = check_output(cmd, shell=True)
    except CalledProcessError as e:
        result = e
        flag = False
    return result, flag


def write2file(filename, content, mode="a+"):
    with open(filename, mode=mode) as f:
        f.write(content)
        f.write('\n')


def get_lcm_node_infos():
    cic = []
    compute = []
    result, _ = call_subprocess(CMD)
    # print(result)

    if not _:
        print("something is worng, please check~")
        print(result)
        sys.exit(1)

    if isinstance(result, bytes):
        result = result.decode()

    infos = result.strip().split('\n')

    if infos:
        for info in infos:
            if re.search('cic', info):
                cic.append(info)
            elif re.search('controller', info):
                cic.append(info)
            elif re.search('contro', info):
                cic.append(info)
            else:
                compute.append(info)

    return cic, compute


def write_node_info(CICS, COMPUTES):
    write2file(node_info, "#!/usr/bin/python", mode="w")

    # write cic info
    temp_cic = []
    if CICS:
        for i in range(len(CICS)):
            write2file(node_info, "CIC%s = '%s'" % (i+1, CICS[i]))
            temp_cic.append("CIC%s" % str(i+1))
    else:
        write2file(node_info, "CIC1 = ''")
        temp_cic.append("CIC1")

    # write compute info
    temp_compute = []
    if COMPUTES:
        for i in range(len(COMPUTES)):
            write2file(node_info, "COMPUTE%s = '%s'" % (i+1, COMPUTES[i]))
            temp_compute.append("COMPUTE%s" % str(i+1))
    else:
        write2file(node_info, "COMPUTE1 = ''")
        temp_compute.append("COMPUTE1")

    # write CIC and COMPUTE
    write2file(node_info, "CICS = %s" % str(temp_cic).replace("'", ""))
    write2file(node_info, "COMPUTES = %s" % str(temp_compute).replace("'", ""))

    write2file(node_info, "ALL_NODES = CICS + COMPUTES")

    # write openrc file info
    write2file(node_info, "OPENSTACK_RC_FILE = '%s'" % str(openrc_file))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=(
        'generate ericic node information.'))
    parser.add_argument('-l', '--lcmrc_file',
                        default='/home/ceeinfra/ceelcmrc',
                        help='lcmrc environment file')
    parser.add_argument('-s', '--sysname',
                        help='lcm system name')
    parser.add_argument('-o', '--openrc_file',
                        help='ceenext environment file')
    args = parser.parse_args()

    """
    lcmrc_file = '/home/ceeinfra/ceelcmrc'
    next_sysname = 'DL33'
    openrc_file = '/var/lib/cee/system/DL33/system/openstack/admin-openrc.sh'
    """
    lcmrc_file = args.lcmrc_file
    next_sysname = args.sysname
    openrc_file = args.openrc_file

    if (not next_sysname) or not (openrc_file):
        print('input error')
        sys.exit(2)

    print("input environment vars is : \n"
          "lcmrc_file: %s \n"
          "next_sysname; %s \n"
          "openrc_file: %s \n" % (lcmrc_file, next_sysname, openrc_file))
    CMD = "source %s && cee clusters hosts list %s openstack " \
          "| grep -vw 'ClusterName' | grep -ivw 'cinder' " \
          "| grep -ivw 'swift' | grep -v 'cic-cinderlcm' | grep -v '+'" \
          " | awk '{print $2}'" % (lcmrc_file, next_sysname)

    CICS, COMPUTES = get_lcm_node_infos()
    write_node_info(CICS, COMPUTES)
    print("please check file %s" % node_info)

