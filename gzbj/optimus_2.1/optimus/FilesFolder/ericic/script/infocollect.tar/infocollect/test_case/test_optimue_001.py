#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os
import re
import sys
import json
sys.path.append(".")
sys.path.append("..")
from common.common import call_subprocess, \
    get_vim_init_data, write2logfile
from common.constant import *

case_name = os.path.basename(__file__).split('.py')[0]

nodes = COMPUTES
excel_file = OUTPUT_VM_USAGE
sheet_name = "vm_info"

sheet_header = (
    'VM ID ', 'VM NAME', 'Status', 'Power State',
    'CPU', 'RAM', 'DISK',  'Created Time',
    'Networks', 'HOST', 'HA', 'AZ', 'Compute state'
)
OUTPUT_INFOS[excel_file].append(
    {
        'sheet': sheet_name,
        'data': []
    }
)


def get_flavors():
    result, _ = call_subprocess(
        FLAVOR, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def get_vm_details():
    ret = []
    keys = [
        'id', 'name', 'status', 'power_state', 'flavor',
        'created', 'host', 'az', 'networks'
    ]
    result, _ = call_subprocess(
        DETAILS, openrc=True
    )
    # print(result)
    if result and (not _):
        return []

    if (not result) or (not result.strip()):
        return []

    if isinstance(result, bytes):
        result = result.decode()

    infos = result.replace('|', '').strip().split('\n')

    for info in infos:
        tmp = {}
        _ = info.strip().split()
        # print(_)
        # print('\n')
        for i in range(len(keys)):
            tmp[keys[i]] = _[i]
            if i == len(keys) - 1:
                tmp[keys[i]] = ''.join(_[i:])
        ret.append(tmp)
    return ret


def get_aggregate():
    ret = []
    result, _ = call_subprocess(
        AGGREGATE_LIST, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    aggs = json.loads(result)
    for agg in aggs:
        tmp, _ = call_subprocess(
            AGGREGATE_SHOW % agg.get('Name'), openrc=True
        )
        ret.append(json.loads(tmp))

    return ret


def get_hypervisor():
    result, _ = call_subprocess(
        HYPERVISOR, openrc=True
    )
    if (not result) or (not result.strip()):
        return []
    else:
        return json.loads(result)


def get_date():
    flavors = get_flavors()
    vms = get_vm_details()
    ha = get_aggregate()
    computes = get_hypervisor()
    return {
        "flavor": flavors,
        "vm_info": vms,
        "aggregate": ha,
        "compute_info": computes
    }


def test():
    data_infos = get_date()
    # print(data_infos)
    filename = '/tmp/optimus_vms_usage'
    if os.path.exists(filename):
        os.remove(filename)
    write2logfile(json.dumps(data_infos), filename)

    flavors = data_infos.get('flavor')
    vms = data_infos.get('vm_info')
    ha = data_infos.get('aggregate')
    computes = data_infos.get('compute_info')

    data = get_vim_init_data(
        OUTPUT_INFOS, excel_file, sheet_name, sheet_header
    )
    if not computes:
        data.append(
            [None for i in range(len(sheet_header))]
        )
        return case_name, OUTPUT_INFOS[excel_file]

    for compute in computes:
        compute_status = compute.get('State', None)
        host = compute.get('Hypervisor Hostname')

        HA = None
        AZ = 'nova'
        if ha:
            for agg in ha:
                if host in agg.get('hosts'):
                    HA = agg.get('name')
                    AZ = agg.get('availability_zone')
                    break

        none_vms_and_compute = [
                    None, None, None, None, None, None,
                    None, None, None, host, HA, AZ,
                    compute_status
        ]
        if not vms:
            if none_vms_and_compute not in data:
                data.append(
                    none_vms_and_compute
                )
        else:
            for vm in vms:
                if not re.search(vm.get('host'), host):
                    if none_vms_and_compute not in data:
                        data.append(
                            none_vms_and_compute
                        )
                else:
                    if none_vms_and_compute in data:
                        data.remove(none_vms_and_compute)
                    vm_id = vm.get('id')
                    vm_name = vm.get('name')
                    vm_status = vm.get('status')
                    create = vm.get('created')
                    network = vm.get('networks')

                    if int(vm.get('power_state')) == 1:
                        vm_power_state = 'Running'
                    elif int(vm.get('power_state')) == 0:
                        vm_power_state = 'NOSTATE'
                    elif int(vm.get('power_state')) == 4:
                        vm_power_state = 'Shutdown'

                    cpu = ram = disk = None
                    for flavor in flavors:
                        if vm.get('flavor') == flavor.get('ID'):
                            cpu = flavor.get('VCPUs')
                            ram = flavor.get('RAM')
                            disk = flavor.get('Disk')

                    data.append(
                        [
                            vm_id, vm_name, vm_status, vm_power_state,
                            cpu, ram, disk, create, network,
                            host, HA, AZ, compute_status
                        ]
                    )

        tmp = []
        for d in data:
            tmp.append(d[-3])
        if tmp.count(host) >= 2:
            data.remove(none_vms_and_compute)

    return case_name, OUTPUT_INFOS[excel_file]


if __name__ == '__main__':
    print(test())
