#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Author: fan.a.wang@ericsson.com

import os
import re
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from subprocess import check_output, CalledProcessError
from common.constant import OPENRC_FILE, TOKEN, CIC1, \
    ENDPOINT_INFOS, TEST_MOUDLE


_LOG_PATH = os.path.abspath(
    os.path.dirname(
        os.path.dirname(__file__))) + os.sep + 'logs'


def get_excel_file_from_test_case(case):
    for k, v in TEST_MOUDLE.items():
        if case in v:
            return k + ".xlsx"
    return ""


def get_token_infos():
    result, _ = call_subprocess(
        TOKEN, host=CIC1, openrc=True
    )
    if not result:
        return None
    return eval(result)


def get_endpoint_infos(service_name=None):
    result, _ = call_subprocess(
        ENDPOINT_INFOS, host=CIC1, openrc=True
    )
    if not result:
        return None
    if not service_name:
        return eval(result)
    else:
        ret = []
        for info in eval(result):
            if info.get('Service Name') == service_name:
                ret.append(info)
        return ret


def write2logfile(content, logfile, mode='a+'):
    with open(logfile, mode) as f:
        f.write(str(content) + '\n')


def get_range_format(ranges):
    """
    :param ranges: 1-4 0r 1
    :return:
    """
    ret = []
    if re.search('-', ranges):
        start = ranges.split('-')[0]
        end = ranges.split('-')[-1]
        for i in range(int(start), int(end) + 1):
            ret.append(i)
    else:
        ret.append(ranges)
    return ret


def get_vim_init_data(infos, filename, name, header):
    for info in infos.get(filename):
        if info.get('sheet') == name:
            info.get('data').append(header)
            return info.get('data')


def call_subprocess(cmd, host=False, openrc=False):
    flag = True
    log_file = _LOG_PATH + os.sep + 'cmd.txt'
    try:
        if openrc:
            cmd = OPENRC_FILE + "; " + cmd
        if host:
            cmd = 'ssh %s "%s"' % (host, cmd)
        print("run command :%s" % cmd)
        print('\n')
        result = check_output(cmd, shell=True)
    except CalledProcessError as e:
        result = e
        flag = False
    write2logfile(cmd, log_file)
    write2logfile("Command Status: %s" % flag, log_file)
    write2logfile("Command Result: %s" % result, log_file)
    write2logfile('\n\n\n', log_file)
    return result, flag


class SSHClient(object):
    def __init__(self):
        pass


class InitWorkbook(object):
    def __init__(self, filename):
        self.name = filename
        if not os.path.exists(self.name):
            self.wb = Workbook()
            self.all_sheets = None
            try:
                self.wb.save(filename=self.name)
            except PermissionError as e:
                print(e)
                print("if your hava open file %s, "
                      "please close the file first. "
                      "And re-try." % self.name)
                exit(1)
        else:
            self.wb = load_workbook(self.name)


class BaseWrokbook(object):
    def __init__(self, filename, workbook):
        self.name = filename
        self.wb = workbook
        self.all_sheets = self.wb.sheetnames
        self.alignment = Alignment(wrapText=True)
        self.title_font = PatternFill("solid", fgColor="7EC0EE")

    def init_sheet(self, titles):
        if isinstance(titles, list):
            for title in reversed(titles):
                # print("all_sheets: %s" % self.all_sheets)
                if not (title in self.all_sheets):
                    self.__dict__['self.ws_%s_%s' % (
                        self.name,
                        title
                    )] \
                        = self.wb.create_sheet(title, 0)
                else:
                    self.__dict__['self.ws_%s_%s' % (
                        self.name,
                        title
                    )] \
                        = self.wb[title]
        else:
            print("Excel file %s, sheet name type error %s; "
                  "it must be list"
                  % (self.name, type(titles))
                  )
            exit(1)

    def get_sheet_wb(self, sheet):
        ws = 'self.ws_{}_{}'.format(self.name, sheet)
        return getattr(self, ws)

    def read(self):
        pass

    def write(self, input, sheet):
        try:
            data = list(zip(*input))
            write2logfile(
                "write to excel data %s, sheet: %s"
                % (list(zip(*data)), sheet),
                logfile=_LOG_PATH + os.sep + 'data.txt'
            )
            # print("write to excel data %s, sheet: %s" % (data, sheet))
            ws = self.get_sheet_wb(sheet)

            # add sheet title color
            for c in range(len(data)):
                ws[str(get_column_letter(c+1)) + str(1)].fill =\
                    self.title_font

            row_len = len(data[0])
            col_len = len(data)
            for col in range(col_len):
                for row in range(row_len):
                    ws.cell(row=row+1, column=col+1, value=str(data[col][row]))
                    if re.search(r"\n", str(data[col][row])):
                        ws[str(get_column_letter(col+1)) + str(row)]\
                            .alignment = self.alignment
            self.wb.save(self.name)
        except Exception as e:
            print("write data to excel failed!")
            print(e)
            exit(1)


if __name__ == "__main__":
    print("")
    print(get_endpoint_infos())
    print(get_endpoint_infos("cinderv3"))
