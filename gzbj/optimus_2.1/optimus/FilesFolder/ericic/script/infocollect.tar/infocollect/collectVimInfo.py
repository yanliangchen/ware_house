#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Author: fan.a.wang@ericsson.com

import os
import shutil
import importlib
from common.constant import *
from common.common import BaseWrokbook, InitWorkbook,\
    get_excel_file_from_test_case

base_path = os.path.split(
    os.path.realpath(__file__))[0]
output_path = base_path + os.sep + 'output'
log_path = base_path + os.sep + 'logs'


class CallAllTests(object):
    def __init__(self):
        self.files = os.listdir('test_case')
        self.list = list(
            set(i.split('.')[0]
                for i in self.files if '__init__' not in i)
        )
        if '' in self.list:
             self.list.remove('')

    def run(self):
        """
        :return:
        """
        def filte_run_test_case(module):
            """
            :param module:
            :return:
            """
            ret = []
            if RUN_TEST_CASE:
                for m in module:
                    if m.replace("test_case.", "") in RUN_TEST_CASE:
                        ret.append(m)
            else:
                ret = module
            return ret

        _modules = []
        for i in self.list:
            _modules.append('.'.join(['test_case', i]))

        filte_case_modules = filte_run_test_case(_modules)
        modules = filte_case_modules

        ret = []
        # print("ALL Test Case: %s" % modules)
        for i in modules:
            try:
                instance = importlib.import_module(i)
                if hasattr(instance, 'test'):
                    print("#" * 100)
                    print("Running Test Case: %s" % i)
                    casename, data = instance.test()
                    ret.append(
                        {
                            casename: data
                         }
                    )
            except AttributeError as e:
                # print(e)
                pass
            except Exception as e:
                # print(e)
                pass
        # print(ret)

    def write(self):
        temp_file = []
        if RUN_TEST_CASE:
            for case in RUN_TEST_CASE:
                temp_file.append(get_excel_file_from_test_case(case))

        for file, sheet_infos in OUTPUT_INFOS.items():
            if temp_file and (file not in temp_file):
                continue
            file = output_path + os.sep + file
            workbook = InitWorkbook(file).wb
            wb = BaseWrokbook(file, workbook)
            _sheet_infos = []
            for s in sheet_infos:
                if s not in _sheet_infos:
                    _sheet_infos.append(s)
            for sheet_info in _sheet_infos:
                _sheet = sheet_info.get('sheet', None)
                data = sheet_info.get('data', None)
                if _sheet and len(_sheet) >= 31:
                    sheet = _sheet[-30:]
                else:
                    sheet = _sheet
                if sheet:
                    wb.init_sheet(titles=[sheet])
                if data and sheet:
                    wb.write(input=data, sheet=sheet)


if __name__ == "__main__":
    for path in [log_path, output_path]:
        shutil.rmtree(path)
        os.mkdir(path)
    info = CallAllTests()
    info.run()
    info.write()
